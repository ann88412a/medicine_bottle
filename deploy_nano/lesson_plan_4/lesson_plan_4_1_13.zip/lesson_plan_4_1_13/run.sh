#!/bin/sh

python3 /home/medical/Desktop/lesson_plan_4_1_13/DAI.py 

